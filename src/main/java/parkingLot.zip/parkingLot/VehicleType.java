package parkingLot;

public enum VehicleType {
    TwoWheeler, FourWheeler;
}
