package parkingLot;

import java.util.Vector;

public class ParkingSpot {
   int id;
   Vehicle vehicle;

   boolean isEmpty;

   int price;

    public ParkingSpot(int id, int price) {
        this.id = id;
        this.isEmpty = true;
        this.price = price; // default price when a parking gets added.
    }

    void parkVehicle(Vehicle v) {
        this.vehicle = v;
        this.isEmpty = false;
    }

    void removeVehicle() {
        this.vehicle = null;
        this.isEmpty = true;
    }


}
