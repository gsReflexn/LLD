package parkingLot;

import java.util.List;

public class TwoWheelerManager extends  ParkingLotManager{


    public TwoWheelerManager(List<ParkingSpot> spots) {
        super(spots);
    }

    @Override
    ParkingSpot findParkingSlot() {
        //logic for finding the nearest parking slot for two wheeler
        return null;
    }
}
